
public class ch6no02 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SutdaCard card1 = new SutdaCard(3,false);
		SutdaCard card2 = new SutdaCard();
		
		System.out.println(card1.info());
		System.out.println(card2.info());

	}

}

class SutdaCard
{
	int num;
	boolean isKwang;
	public SutdaCard()
	{
		/*num = (int)(Math.random()*10+1);
		if(num == 1||num == 3||num == 8)
		{
			int ran = (int)(Math.random()*1);
			if(ran == 1)
				isKwang = true;
			else
				isKwang = false;
		}*/
		num = 1;
		isKwang = true;
	}
	public SutdaCard(int number,boolean Kwang)
	{
		num = number;
		isKwang = Kwang;
	}
	Object info()
	{
		if(isKwang == true)
		{
			System.out.print(num);
			return 'K';
		}
		else
			return num;
		
	}
}