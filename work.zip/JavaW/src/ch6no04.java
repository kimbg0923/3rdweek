
public class ch6no04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student();
		s.name = "ȫ�浿";
		s.ban = 1;
		s.no = 1;
		s.kor = 100;
		s.eng = 60;
		s.math =76;
		
		System.out.println("�̸� : "+s.name);
		System.out.println("���� : "+s.getTotal());
		System.out.println("��� : "+s.getAverage());

	}
}

class Student{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;

	int getTotal()
	{
		int sum=0;
		sum+=kor;
		sum+=math;
		sum+=eng;
		return sum;
	}
	float getAverage()
	{
		int sum=0;
		float avg;
		sum+=kor;
		sum+=math;
		sum+=eng;
		avg = (int)((sum/3f)*10+0.5f)/10f;
		return avg;
	}

}
