
public class ch6no05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students s = new Students("ȫ�浿",1,1,100,60,76);
		System.out.println(s.info());
		
	}
}

class Students{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;

	public Students(){}
	public Students(String _name, int _ban, int _no, int _kor, int _eng, int _math)
	{
		name = _name;
		ban = _ban;
		no = _no;
		kor = _kor;
		eng = _eng;
		math = _math;
	}
	
	int getTotal()
	{
		int sum=0;
		sum+=kor;
		sum+=math;
		sum+=eng;
		return sum;
	}
	float getAverage()
	{
		int sum=0;
		float avg;
		sum+=kor;
		sum+=math;
		sum+=eng;
		avg = (int)((sum/3f)*10+0.5f)/10f;
		return avg;
	}
	String info()
	{
		System.out.print(name+","+ban+","+no+","+kor+","+eng+","+math+","+getTotal()+","+getAverage());
		return " ";
	}

}