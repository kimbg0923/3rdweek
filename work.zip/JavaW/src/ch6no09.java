class Marine{
	int x=0,y=0;
	int hp = 60;
	static int weapon = 6;
	static int armor = 0;
	
	void weaponUp(){
		weapon++;
	}
	void armorUp(){
		armor++;
	}
	void move(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
public class ch6no09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
