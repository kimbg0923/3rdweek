
public class ch6no20 {

	static int[] shuffle(int[] arr)
	{
		int temp;
		int num;
		int[] result = arr;
		for(int i = 0;i<arr.length;i++)
		{
			num = (int)(Math.random()*arr.length);
			temp = result[i];
			result[i] = result[num];
			result[num] = temp;
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] original = {1,2,3,4,5,6,7,8,9};
		System.out.println(java.util.Arrays.toString(original));
		
		int[] result = shuffle(original);
		System.out.println(java.util.Arrays.toString(result));

	}

}
