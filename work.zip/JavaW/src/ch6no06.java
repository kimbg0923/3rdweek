
public class ch6no06 {

	static double getDistance(int x, int y, int x1, int y1)
	{
		int x_l = (x1-x)*(x1-x);
		int y_l = (y1-y)*(y1-y);
		return Math.sqrt(x_l+y_l);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getDistance(1,1,2,2));

	}

}
